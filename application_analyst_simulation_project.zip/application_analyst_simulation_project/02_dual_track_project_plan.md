# Dual-Track Project Plan

## Project title
**From Lab Bench to Community Care: A Dual-Track Application Analyst Simulation**

## Project concept
You will simulate one week of work as an application analyst supporting two different environments:

- **Track A – Karchem-style lab informatics support**
- **Track B – OCHIN-style Epic Willow Ambulatory support**

Each track uses the same analyst framework:

1. Intake
2. Workflow discovery
3. Requirements documentation
4. Proposed configuration/build change
5. Testing and validation
6. End-user communication/training
7. Issue closure and lessons learned

---

## Track A: Karchem-style scenario

### Scenario
A biotech startup is using a lab informatics platform to manage samples, experiments, and assay results. Scientists report that sample handoffs are inconsistent, metadata is incomplete, and new team members do not know how to enter data correctly. The lab also wants to reduce manual re-entry between experiment tracking and inventory updates.

### Your analyst objective
Design a lightweight support-and-optimization package that improves:
- data entry consistency
- traceability
- onboarding
- workflow clarity
- future readiness for automation/API integration

### What you will build
- current-state workflow map
- future-state workflow map
- requirements list
- proposed configuration changes
- onboarding SOP
- support ticket log
- UAT test script

---

## Track B: OCHIN-style scenario

### Scenario
A community healthcare organization using Epic Willow Ambulatory reports that pharmacy staff and clinic staff are seeing confusion around refill request handling, medication history review, and escalation of support issues after a recent build update. End users need clearer workflows and the analyst team needs better documentation and testing discipline.

### Your analyst objective
Design a support-and-build improvement package that improves:
- workflow clarity
- testing quality
- user support consistency
- training readiness
- documentation of system changes

### What you will build
- clinical/pharmacy workflow observation notes
- requirements document
- change control log
- test/validation script
- issue triage matrix
- end-user quick guide
- lessons-learned summary

---

## Shared analyst competencies this project demonstrates

- business analysis
- workflow mapping
- documentation
- stakeholder communication
- configuration thinking
- testing discipline
- troubleshooting
- training support
- structured escalation

---

## Suggested timeline

### Day 1
Read both role comparisons and define your scenarios.

### Day 2
Build current-state workflows for both tracks.

### Day 3
Write requirements and proposed changes for both tracks.

### Day 4
Create testing scripts and issue triage logic.

### Day 5
Create training guides and interview talking points.

### Day 6
Rehearse your walkthrough aloud.

### Day 7
Convert the project into GitHub-ready portfolio notes and resume bullets.
