# Simulated Daily Workflow

## Shared analyst workflow

### Step 1: Intake and triage
For both roles, start with:
- who reported the issue
- what changed
- business/operational impact
- urgency
- whether the issue is support, enhancement, training, or data quality

### Step 2: Understand the workflow before touching the system
Ask:
- what is the user trying to do?
- what is the expected outcome?
- where does the process break?
- is the issue caused by configuration, training, permissions, workflow design, or data quality?

### Step 3: Document before changing
Create:
- problem statement
- affected users
- workflow notes
- requirements
- assumptions
- risks
- success criteria

### Step 4: Design the change
Define:
- what change is needed
- whether it is configuration, training, documentation, or escalation
- who approves the change
- how it will be tested

### Step 5: Test with discipline
Use test cases that cover:
- normal workflow
- edge cases
- user permissions
- downstream impact
- rollback/failure scenarios

### Step 6: Communicate and train
Prepare:
- concise summary of what changed
- step-by-step user guidance
- who to contact for support
- known limitations

### Step 7: Close the loop
Document:
- resolution
- evidence of testing
- follow-up needs
- prevention ideas

---

## Karchem-style daily workflow

### Morning
Review support inbox and managed-services requests from biotech clients.

Possible ticket types:
- missing sample fields
- broken template logic
- inventory tracking mismatch
- user access issue
- onboarding request
- request for workflow automation

### Midday
Meet with a scientist, lab operations lead, or client contact.

Focus questions:
- what experiment or assay is being supported?
- what metadata needs to be captured?
- where do users create duplicate work?
- what should the data model enforce versus leave flexible?

### Afternoon
Draft or implement a proposed change.

Possible configuration work:
- required metadata fields
- status changes
- template updates
- naming conventions
- role-based permissions
- API handoff recommendations

### End of day
Document the change, update support notes, and prepare user communication or training.

---

## OCHIN-style daily workflow

### Morning
Review analyst queue for support items related to Epic Willow Ambulatory and adjacent workflows.

Possible ticket types:
- refill workflow confusion
- pharmacy queue behavior after update
- medication history review issue
- end-user question about new build
- need for revised training documentation

### Midday
Observe workflow or review current process with experienced analysts and operational users.

Focus questions:
- what is the intended refill/medication workflow?
- what changed after the update or patch?
- is this a workflow issue, user knowledge gap, or build issue?
- what needs escalation?

### Afternoon
Support testing and documentation.

Possible analyst tasks:
- execute test cases
- log defects
- update build/change notes
- improve user guide language
- document known issues and escalation paths

### End of day
Summarize findings, route unresolved issues appropriately, and maintain change records.
