# Interview Translation Guide

## How to explain this project in one paragraph
I built a dual-track application analyst simulation project to prepare for two different analyst environments. One track focused on laboratory informatics support aligned to Karchem Consulting’s ELN/LIMS consulting model, including requirements gathering, workflow mapping, configuration thinking, onboarding support, and automation opportunities. The second track focused on Epic Willow Ambulatory support aligned to OCHIN’s healthcare analyst apprenticeship model, including workflow analysis, system build support, testing, documentation, issue triage, and end-user support.

---

## How to explain the Karchem fit
This track reflects the type of analyst work needed in a biotech consulting environment. I practiced translating scientific workflow needs into structured software requirements, proposing lab-system configuration changes, identifying data-quality risks, and creating onboarding and support documentation. The focus was on understanding how the system should support the science, not just how to fix a ticket.

---

## How to explain the OCHIN fit
This track reflects the type of analyst work needed in a healthcare IT environment supporting Epic Willow Ambulatory. I practiced documenting operational workflows, thinking through testing and validation, improving user support documentation, and distinguishing between training issues, workflow issues, and true build issues. The focus was on reliable, safe, well-documented support for healthcare users.

---

## Compare-and-contrast answer for interviews
The biggest similarity is that both roles require strong workflow analysis, structured documentation, careful testing, and user support. The biggest difference is the operating environment. Karchem’s role is more consulting-oriented and tailored to biotech laboratory processes across varied ELN/LIMS platforms, so the analyst has to think about scientific data models, lab operations, and flexible client-specific configuration. OCHIN’s role is more structured within an Epic healthcare ecosystem, so the analyst has to think about standardized build processes, validation, end-user support, and the operational impact on care delivery.

---

## Strong interview phrases you can use

### Karchem
- “I like analyst work that sits between scientists and systems.”
- “I focus on understanding the workflow before proposing configuration changes.”
- “I think in terms of traceability, usability, and long-term fit for the lab.”
- “I understand that in lab informatics, a system should support the science rather than force bad process workarounds.”

### OCHIN
- “I understand the importance of documentation, validation, and escalation discipline in healthcare IT.”
- “I try to separate a workflow issue from a true application issue before recommending changes.”
- “I value clear support documentation because strong user guidance prevents repeated issues.”
- “I enjoy structured environments where I can learn from experienced analysts while contributing through testing, documentation, and user support.”

---

## Optional GitHub repo name ideas
- `application-analyst-simulation-project`
- `eln-lims-and-epic-analyst-workflow-project`
- `karchem-ochin-analyst-prep`
