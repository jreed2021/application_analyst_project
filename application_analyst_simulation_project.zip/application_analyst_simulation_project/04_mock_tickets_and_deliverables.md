# Mock Tickets and Deliverables

## Track A – Karchem mock tickets

### Ticket KC-01: Missing sample metadata during assay intake
**Problem:** Scientists are creating sample records without required metadata, which makes later analysis difficult.

**Your tasks:**
- identify mandatory versus optional fields
- propose validation/configuration logic
- document revised workflow
- create a one-page data entry guide

**Deliverable:**
A requirements sheet listing required metadata fields, field definitions, and acceptance criteria.

---

### Ticket KC-02: New scientists are entering experiment data inconsistently
**Problem:** Naming conventions and template use vary across team members.

**Your tasks:**
- define standard naming convention
- propose template changes
- create onboarding SOP
- create training checklist

**Deliverable:**
A 1–2 page onboarding SOP plus a training checklist.

---

### Ticket KC-03: Request for automation opportunity review
**Problem:** Lab staff manually re-enter sample and inventory details across steps.

**Your tasks:**
- map current workflow
- identify repeatable handoff points
- recommend whether automation is appropriate
- explain risks, assumptions, and dependencies

**Deliverable:**
A simple workflow memo titled: **Where automation helps and where manual review should remain**.

---

## Track B – OCHIN mock tickets

### Ticket OC-01: Refill workflow confusion after a build update
**Problem:** End users report confusion about the expected refill handling path after a recent update.

**Your tasks:**
- document current workflow
- identify what changed
- write test cases for the expected process
- draft a short support note for users

**Deliverable:**
A test script with expected results and a user-facing quick reference.

---

### Ticket OC-02: Medication history review steps are inconsistently followed
**Problem:** Staff are not using the same sequence when reviewing medication history, causing inconsistent support requests.

**Your tasks:**
- create workflow observation notes
- separate workflow issue from training issue
- propose documentation improvements
- define escalation criteria

**Deliverable:**
A troubleshooting matrix: issue type, likely cause, first action, escalation path.

---

### Ticket OC-03: End-user training material needs refresh
**Problem:** Existing support documentation is too long and hard for staff to follow.

**Your tasks:**
- rewrite instructions in clearer language
- organize steps by role or task
- include known support contacts/escalation path

**Deliverable:**
A one-page quick guide for end users.

---

## Suggested templates

### Requirements template
- issue title
- business/workflow context
- affected users
- current pain point
- proposed change
- risks
- dependencies
- acceptance criteria

### Test script template
- test case ID
- scenario
- precondition
- steps
- expected result
- actual result
- pass/fail
- notes

### Troubleshooting log template
- incident date
- reported by
- issue summary
- suspected cause
- action taken
- escalation needed
- resolution status
- documentation updated? yes/no
